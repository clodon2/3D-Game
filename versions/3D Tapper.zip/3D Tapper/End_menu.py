from ursina import Entity, camera, Text, Sprite, application, color


title_font = "other/OldePixel.ttf"
button_font = "other/OldePixel.ttf"
info_font = "other/OldePixel.ttf"


class DeathMenu(Entity):
    def __init__(self):
            self.background = Sprite('shore', x=1, z=1, color=color.black)
            super().__init__(parent=camera.ui, ignore_paused=True)
            Text(text=f"You   Lost!", font='other/OldePixel.ttf', scale = 2.0, x=-.25, y=.10)

    def stop(self):
        application.quit()
