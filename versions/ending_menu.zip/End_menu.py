from ursina import Entity, invoke, scene, camera, Text

title_font = "other/OldePixel.ttf"
button_font = "other/OldePixel.ttf"
info_font = "other/OldePixel.ttf"


class DeathMenu(Entity):
    def __init__(self):
        super().__init__(parent=camera.ui, ignore_paused=True)
        game_over_text = Text("You Ran Out of Lives", scale=2.2, font=title_font, parent=self, y=0.3, x=0,
                              origin=(0,0), resolution=1080*Text.size)

